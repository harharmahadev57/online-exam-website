# Online Exam Website
This is a basic structure for an online exam system.